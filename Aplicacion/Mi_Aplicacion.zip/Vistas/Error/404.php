	<html>
		<head>
			<title>.:: Pagina No Encontrada ::.</title>
			<style>
				body {
					font-family: verdana;
					background: url('<?php echo __NeuralUrlFileRoot__; ?>Public/images/background_404.png') no-repeat center center fixed;
					-webkit-background-size: cover;
					-moz-background-size: cover;
					-o-background-size: cover;
					background-size: cover;
				}
				
				.contenido {
					position: absolute;
					left: 50%;
					top: 50%;
					width: 500px;
					height: 300px;
					margin-top: -150px;
					margin-left: -200px;
					overflow:hidden;
				}
				
				.centrado {
					text-align: center;
					color: #330099;
					font-family: ROCKWELL;
				}
				
				.parrafo {
					font-family: verdana;
					font-size: 10px;
					text-align: center;
					display: block;
				}
			</style>
		</head>
		<body>
			<div class="contenido">
				<h1 class="centrado">404: Pagina No Encontrada</h1>
				<p class="parrafo">La pagina que estas tratando de visualizar no se encuentra, por favor realizar la validacion con el administrador del sistema.</p>
			</div>
		</body>
	</html>